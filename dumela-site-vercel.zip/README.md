# Dumela Consultoria

Site institucional estático, responsivo e pronto para publicação na Vercel.

## Testar localmente

```bash
npm run dev
```

## Publicar

1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Na Vercel, escolha **Add New > Project**.
3. Importe o repositório.
4. Em **Framework Preset**, selecione **Other**.
5. Não preencha Build Command nem Output Directory.
6. Clique em **Deploy**.

Para usar o domínio `dumelaconsultoria.com.br`, adicione-o em **Settings > Domains** na Vercel e siga os registros DNS informados.
