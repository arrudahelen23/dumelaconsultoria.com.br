import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const html = await readFile(new URL("../index.html", import.meta.url), "utf8");

test("site has mobile viewport and Portuguese language", () => {
  assert.match(html, /<html lang="pt-BR">/);
  assert.match(html, /width=device-width/);
});

test("contact data is configured", () => {
  assert.match(html, /5585936182341/);
  assert.match(html, /contato@dumelaconsultoria\.com\.br/);
});

test("essential sections exist", () => {
  for (const id of ["inicio", "atuacao", "proposta", "desafios", "sobre", "contato"]) {
    assert.match(html, new RegExp(`id=["']${id}["']`));
  }
});

